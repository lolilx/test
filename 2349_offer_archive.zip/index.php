<?php

session_start();
$_SESSION["p"] = $_GET['p'] ?? '';
$_SESSION["sub_id1"] = $_GET['sub_id1'] ?? '';
$_SESSION["sub_id2"] = $_GET['sub_id2'] ?? '';
$_SESSION["sub_id3"] = $_GET['sub_id3'] ?? '';
$_SESSION["sub_id4"] = $_GET['sub_id4'] ?? '';
$_SESSION["sub_id5"] = $_GET['sub_id5'] ?? '';
$_SESSION["aff_param1"] = $_GET['aff_param1'] ?? '';
$_SESSION["aff_param2"] = $_GET['aff_param2'] ?? '';
$_SESSION["aff_param3"] = $_GET['aff_param3'] ?? '';
$_SESSION["aff_param4"] = $_GET['aff_param4'] ?? '';
$_SESSION["aff_param5"] = $_GET['aff_param5'] ?? '';
$_SESSION["p"] = $_GET['p'] ?? '';
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Blog Seks Indonesia </title>
    <link rel="icon" href="files/img/prod.png" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="files/css/style.css">
    <link rel="stylesheet" href="files/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <style type="text/css">
        .footer-fixed {
            background: rgba(0, 0, 0, .68);
            position: fixed;
            bottom: 0;
            width: 100%;
            max-width: 600px;
            text-align: center;
            z-index: 21;
            font-size: 36px
        }

        .footer-fixed div a,
        .footer-fixed div p {
            display: inline-block;
            color: #fff;
            font-size: 22px;
            font-family: 'Roboto Condensed', sans-serif;
        }

        .footer-fixed div p {
            padding: 1px 6px;
            line-height: 5px;
        }

        .footer-fixed div a {
            padding: 6px 8px;
            font-size: 21px;
        }

        .footer-fixed a {
            padding: 20px;
            background: #e31c02;
            border-radius: 10px
        }

        @media (max-width: 767px) {
            .footer-fixed div p {
                font-size: 16px;
                line-height: 1.2;
                margin: 0 5px 0 0;
                padding: 0;
            }

            .footer-fixed div a {
                font-size: 12px;
                padding: 9px 8px
            }

            .footer-fixed {
                padding-top: 7px;
                padding-bottom: 7px
            }

            .footer-fixed > div {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                justify-content: center;
                -webkit-box-orient: horizontal;
                -webkit-box-direction: normal;
                -ms-flex-direction: row;
                flex-direction: row;
            }

        }
    </style>

    <!-- INTH_SNIPPET_TOP -->
    <style>
        .ever-popup-build {
            position: fixed;
            opacity: 0;
            z-index: -1;
            top: 0;
            left: -9999px;
        }
    </style>
    <style>
        @media screen and (max-width: 999px) {
            .ever-popup {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, .7);
                z-index: 111;
                display: none;
                overflow: auto;
            }

            .ever-popup__body {
                position: static;
                float: none;
                display: block;
                margin: 0 auto;
                width: auto
            }

            .ever-popup.show {
                display: block;
                align-items: center;
            }

            .ever-popup__inner {
                position: relative;
                margin: 0 auto;
                padding-top: 35px
            }

            .ever-popup__close {
                width: 35px;
                height: 30px;
                position: absolute;
                cursor: pointer;
                top: 0;
                right: 0;
                z-index: 1;
                -webkit-transition: .3s;
                -moz-transition: .3s;
                -ms-transition: .3s;
                -o-transition: .3s;
                transition: .3s;
            }

            .ever-popup__close:after,
            .ever-popup__close:before {
                content: "";
                position: absolute;
                right: 0;
                top: 10px;
                width: 35px;
                height: 10px;
                background: #fff;
                transition: all 1s;
            }

            .ever-popup__close:after {
                -webkit-transform: rotate(-45deg);
                -ms-transform: rotate(-45deg);
                -o-transform: rotate(-45deg);
                transform: rotate(-45deg);
            }

            .ever-popup__close:before {
                -webkit-transform: rotate(45deg);
                -ms-transform: rotate(45deg);
                -o-transform: rotate(45deg);
                transform: rotate(45deg);
            }
        }
    </style>
    <!--[HEADER]-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="//code.jivosite.com/widget/j870uURlFB" async></script>
</head>

<body>
<span id="warning-container"><i data-reactroot=""></i></span>

<header class="lt0"><b>SexBlog </b> Afrique</header>
<div class="topimg" bis_skin_checked="1">
    <a href=""><img alt="" class="img-responsive" src="files/img/out1.gif"></a>
</div>
<main>
    <h1 class="lt1">Alfaman = <span>2 jam berhubungan seks dan +6 cm</span></h1>
    <div class="golova" bis_skin_checked="1">
        <h2 class="lt2"> Suamiku tidur denganku selama 2 jam dan penisnya sekeras batu!</h2>
        <ul>
            <li class="lt3">Jama Faye</li>
            <li>❤️34912</li>
            <li>👍8853</li>
        </ul>
    </div>
    <div class="story" bis_skin_checked="1">
        <h3 class="lt4">- Oh! Mengapa saya memberinya pil ini? Seseorang selamatkan aku dari monster ini!</h3><a
                href=""><img alt="" class="img-responsive" src="files/img/24438660.webp"></a>
        <blockquote class="lt5">Penis yang lebih kencang dan besar meningkatkan kualitas seks</blockquote>
        <p class="lt6">Hai teman. Apakah Anda ingat postingan di mana saya mengeluh bahwa suami saya Mamadou tidak bisa memuaskan saya? Penisnya tidak bisa tetap kencang bahkan setelah rangsangan oral yang dalam, dan sejujurnya, ukurannya juga terlalu kecil untukku!</p>
        <p class="lt7">Kami mencoba segalanya: Viagra, stimulan ereksi lainnya, yoga, praktik tantra. Tak satu pun dari hal ini membantu kami sama sekali. Penisnya tetap lunak atau akan lemas ketika tiba waktunya untuk dimasukkan. Seks tidak pernah berlangsung lebih dari dua menit 😞😥.</p>
        <p class="lt8">Saya pikir itu karena faktor genetik atau terkait dengan kondisi fisiknya, yang tidak memungkinkan dia untuk melakukan hubungan intim dalam waktu lama, dan tidak ada yang bisa kami lakukan untuk mengatasinya. Saya harus menerimanya.</p>
        <p class="lt9">
            Tentu saja, saya tidak dapat memungkiri bahwa saya sangat ingin bercinta berjam-jam karena saya seorang wanita muda yang cantik, dan saya belum siap untuk melepaskan kesenangan saya. Saya ingin merasa kenyang dan memiliki dia di dalam diri saya. Tapi aku juga tidak ingin selingkuh dari Mamadou.
        </p>
        <blockquote class="lt10">Saya menemukan solusi ketika saya sudah kehilangan harapan...</blockquote>
        <p class="lt11">Ketika saya kehilangan harapan, saya melihat acara TV bersama Hugh Hefner (pemilik majalah Playboy) yang mengatakan bahwa pria mana pun boleh berhubungan seks selama 2 jam berturut-turut. Bahkan di usianya. Tetapi dengan satu syarat: Anda harus memiliki banyak testosteron dalam darah Anda 💪💪💪
            (hormon utama pria)!</p><a href=""><img class="comimg" src="files/img/6.gif"></a>
        <p class="lt12">Menurut Hugh, peningkatan jumlah testosteron akan memberi Anda banyak energi untuk bercinta berjam-jam. Testosteron meningkatkan hasrat seksual dan meningkatkan kekuatan pria. Hormon ini membantu pria memuaskan wanitanya selama berjam-jam melakukan hubungan seks yang tak terlupakan...</p>
        <p class="lt13">Hugh merekomendasikan penggunaan <a href="">Alfaman</a> untuk meningkatkan kekuatan pria, yang dia gunakan sendiri, jadi saya membuka situs webnya dan memesan 3 bungkus produk ini.
        </p><a href=""><img alt="" class="img-responsive" src="files/img/img03.jpg"></a>
        <p><span class="doc-quote lt14">
        "Obat ini memperbaiki kondisi sistem genitourinari dan secara signifikan meningkatkan kadar testosteron, hormon utama pria. Dengan penggunaan teratur, hasrat seksual meningkat, ereksi lebih kuat, menyebabkan orgasme lebih lama dan intens!"
        </span></p>
        <blockquote class="lt15">Apakah hasilnya?</blockquote>
        <p class="lt16">Paket tiba dengan cepat, dan saya tidak sabar menunggu dimulainya perawatan. Beberapa hari kemudian, suami saya menggunakannya.</p>

        <p class="lt17">Saya malu menceritakan apa yang terjadi setelah 3 minggu pengobatan😊😍🙈. Sial, aku benar-benar bingung! Tapi karena kita tidak mengenal satu sama lain, saya akan menceritakan semua detailnya.</p>
        <p class="lt18">
            Tentu saja, aku mengharapkan perbaikan... tapi cara Mamadou meniduriku setelah perawatan dengan pil ini adalah sesuatu yang bahkan tidak pernah kubayangkan dalam fantasiku.
        </p>
        <p class="lt19">
            Setiap malam, dia mendatangi saya dengan EREKSI YANG LUAR BIASA DAN KERAS! Dia menyentuh penisnya dengan takjub, dan ada api binatang di matanya! Dia membalikkan badanku dan masuk dari belakang. Itu luar biasa!
        </p>
        <p class="lt20">Kamu tidak akan percaya, tapi dia meniduriku seperti binatang buas, selama sekitar 2 jam! Dan ini setelah hampir 3 tahun mengalami impotensi seksual dan kurangnya hubungan seks. Kasar! Keras! Nonstop! Dia menaruhnya di kedua lubang, dan saya tidak keberatan sama sekali😋😆🍌🍌🍌</p>
        <p class="lt21">Kenikmatan yang luar biasa, banyak keringat, dan banyak erangan!</p>
        <p class="lt22">Ya, itu adalah seks terbaik dalam hidup kami! Seolah-olah aku sedang bersama tiga pria sekaligus.</p>
        <p class="lt23">Saya tidak percaya obat ini mengubah Mamadou saya menjadi laki-laki alfa sejati, dan semuanya harus dibayar dengan harga tiket bioskop.</p>
        <p class="lt24"> Saya pikir hasilnya sangat berharga: hidup ini singkat, dan saya bukan salah satu dari gadis-gadis yang tidak ingin menghabiskan uang untuk bersenang-senang! (Itu saja untuk hari ini, Mamadou sudah tidur, selamat malam semuanya!!!  👌😁💓💓💓</p>

        <br>
        <div style="border: dashed red 4px;"><p class="lt25" style="font-weight:bold">Para ahli mengatakan bahwa prinsip produk ini adalah mengiritasi reseptor kulit, memaksa aliran darah ke jaringan penis, yang menyebabkan peningkatan awal. Produk ini juga merangsang pembelahan sel, yang menyebabkan penis tumbuh.
            <a href="">Alfaman</a> adalah alternatif yang aman untuk operasi. Apalagi cara memperbesar penis ini tidak memerlukan investasi serius dan tidak menimbulkan efek samping.</p>
            <a href=""> <img alt="" class="img-responsive" src="files/img/prod.png"></a></div>
        <br>
        <p class="lt25">Mamadou menggunakan produk ini sesuai petunjuk, dan kami lebih bahagia dari sebelumnya. Ada hari-hari ketika dia meniduriku selama tiga jam berturut-turut seperti binatang. Selain itu, Mamadou kini terlihat lebih berotot dan memiliki perut (semuanya berkat testosteron!). Saya pikir obat ini dirancang untuk meningkatkan kesehatan seksual, namun saya terkejut melihat bagaimana tubuhnya berubah dan tampilannya menjadi sporty!
        </p><a href=""><img alt=""
                                                                                                            class="img-responsive"
                                                                                                            src="files/img/3.gif"></a>
        <p class="lt26">Mamadou berhenti menggunakan <a href="">Alfaman</a> tiga bulan lalu. Namun kini, ereksinya bertahan lama, dan ukurannya pun begitu besar.</p>
        <p class="lt27">Minggu lalu, kami menghubungi konsultan produk <a href="">Alfaman</a> untuk mengetahui apakah Mamadou harus terus menggunakan produk tersebut. Perwakilan tersebut memberi tahu kami bahwa pengobatan ini memiliki efek kumulatif jangka panjang yang bertahan selama bertahun-tahun, jadi Anda sebaiknya tidak meminumnya lagi untuk saat ini.</p>
        <p class="lt28">Kesimpulannya, kehidupan seks kami meningkat secara signifikan berkat <a href="">Alfaman</a>, dan kami sangat bahagia 😏. Tentu saja, saya dapat merekomendasikan produk pembesar penis ini kepada semua orang, terutama mereka yang ingin meningkatkan kehidupan seksnya tanpa menggunakan Viagra atau stimulan berbahaya lainnya.</p>
        <p><a class="lt29" href="">CEPAT DAN ORDER MENGGUNAKAN FORMULIR DI BAWAH INI!</a></p>
        <p class="lt30">
            Konsultannya sangat ramah, kompeten, dan berpengetahuan luas tentang semua masalah kesehatan pria. Semua konsultasi bersifat anonim dan diberikan melalui telepon. Jangan khawatir soal pengiriman, produk akan sampai dalam kemasan tertutup rapat sehingga tidak ada yang tahu isinya.
        </p>
    </div>

    <div class="toform" id="toform" bis_skin_checked="1"></div>
    <div class="toland lt31" bis_skin_checked="1"><span>DISKON 50</span> Promosi ini berlangsung hingga<strong>
            <script>
                function addZero(i) {
                    if (i < 10) {
                        i = "0" + i
                    }
                    return i
                }

                var days = 0;
                var date = new Date();
                var last = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
                var day = addZero(last.getDate());
                var month = addZero(last.getMonth() + 1);
                var year = last.getFullYear();
                var sNow = day + "." + month + "." + year;
                document.write(sNow);
            </script>
            <p style="color: #a9161a; margin: 0;"><span class="x_price_previous"
                                                        style="display: inline; font-size: 18px;"><span
                            class="old_price"
                            style="display: inline; text-decoration: line-through; text-decoration-thickness: 5px; text-decoration-color:#a9161a;">650.000 IDR</span></span><span
                        class="x_currency" style="display: inline; font-size: 18px;"><span class="currency_price"
                                                                                           style="display: inline;"></span></span>
            </p>
            <p style="color: #ff0000; font-size: 30px; margin: 0;"><span class="x_price_current"
                                                                         style="display: inline;"><span
                            class="new_price" style="display: inline;">325.000 IDR</span> </span><span class="x_currency"
                                                                                                     style="display: inline;"><span
                            class="currency_price" style="display: inline;"></span></span></p>
        </strong></div>
    <div class="buynow" style="text-align:center;" bis_skin_checked="1">
        <a href=""><img alt="" class="order_widget-img" src="files/img/prod.png" width="200"></a>
        <ul>
            <li class="lt32">Ereksi Kuat</li>
            <li class="lt33">100% Alami</li>
            <li class="lt34">Seks Lebih Lama</li>
            <li class="lt35">Ukuran Penis Lebih Besar</li>
            <li class="lt36">Orgasme yang Fantastis</li>
            <li class="lt37">Libido Sangat Tinggi</li>
        </ul>
        <form class="landing__form order_form  orderForm" id="order_form"
              action="send.php" method="post">
            <input type="hidden" name="p" value="{p}">
            <input type="hidden" name="aff_click_id" value="{subid}"/>
            <input type="hidden" name="p" value="<?php echo $_SESSION["p"]; ?>">
            <input type="hidden" name="sub_id1" value="{campaign_id}">
            <input type="hidden" name="sub_id2" value="<?php echo $_SESSION["sub_id2"]; ?>">
            <input type="hidden" name="sub_id3" value="<?php echo $_SESSION["sub_id3"]; ?>">
            <input type="hidden" name="sub_id4" value="<?php echo $_SESSION["sub_id4"]; ?>">
            <input type="hidden" name="sub_id5" value="<?php echo $_SESSION["sub_id5"]; ?>">
            <input type="hidden" name="aff_param1" value="<?php echo $_SESSION["aff_param1"]; ?>">
            <input type="hidden" name="aff_param2" value="<?php echo $_SESSION["aff_param2"]; ?>">
            <input type="hidden" name="aff_param3" value="<?php echo $_SESSION["aff_param3"]; ?>">
            <input type="hidden" name="aff_param4" value="<?php echo $_SESSION["aff_param4"]; ?>">
            <input type="hidden" name="aff_param5" value="<?php echo $_SESSION["aff_param5"]; ?>">

            <div class="name-input" bis_skin_checked="1">
                <input name="name" placeholder="Nama" required="" type="text" value="">
            </div>
            <div class="phone-input" bis_skin_checked="1">
                <label for="phone-input"></label>
                <input class="phone-black" autocomplete="tel" id="phone-input" name="phone" placeholder="Telepon"
                       minlength="5" required="" type="tel" value="">
            </div>
            <button class="button-submit" id="send_order" type="submit"><span class="button-submit-text lt38">BELI Alfaman</span>
            </button>
        </form>
    </div>
    <div class="commentarios lt39" bis_skin_checked="1">Komentar</div>
    <div class="comenti" bis_skin_checked="1">
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-01.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt40" href="">MARIAMA</a>
                </p>
                <p class="comment lt41">Pacar baruku memiliki penis terbesar yang pernah kulihat. Saya belum pernah bersenang-senang dengan seks sebelumnya. 👍 Saya tidak mengerti bagaimana dia melakukannya, tetapi baru-baru ini dia mengungkapkan sebuah rahasia kepada saya: dia menggunakan produk ini. 💪😎</p>
                <p>

                </p>
                <a href=""></a>
            </div>


        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-02.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt42" href="">OUSMANE</a>
                </p>
                <p class="comment lt43">Saya telah mengonsumsi <a href="">Alfaman</a> selama beberapa minggu sekarang, dan saya merasa lebih bahagia dari sebelumnya! Penisku menjadi keras dan sedikit lebih besar. Bahkan setelah aku cum, aku masih punya kesalahan bodoh! Gadis-gadis, jangan tinggalkan aku sendiri! 😁
                </p><a href=""><img alt=""
                                                                                                                  class="comimg"
                                                                                                                  src="files/img/coment1.jpg"
                                                                                                                  style="width: 50%;"></a>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-03.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt44" href="">BABACAR</a>
                </p>
                <p class="comment lt45">
                    TERIMA KASIH. ❤ Saya mulai mengonsumsi <a href="">Alfaman</a> dua minggu lalu, dan saya sendiri tidak mengharapkan hasil seperti itu! Sekarang saya bisa bercinta selama satu jam atau lebih! Suasana hati dan kesehatan saya membaik! Sungguh luar biasa!
                </p><a href=""></a>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-06.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt46" href="">MOUSSA </a></p>
                <p class="comment lt47">Teman dari Amerika bilang kalau laki-laki di sana juga pakai <a href="">Alfaman</a>, tapi saya belum mencobanya. 🤔🤔</p>

            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-08.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt48" href="">FATOUMATA</a>
                </p>
                <p class="comment lt49">Saya pun memutuskan untuk memesan produk ini untuk suami saya selagi diskon masih ada. 👍😱</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-07.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt50" href="">ABDOU</a>
                </p>
                <p class="comment lt51">
                    Saya telah menggunakan produk ini selama sebulan sekarang, dan saya tidak dapat mempercayai mata saya! ku sekeras batu dan bahkan sudah membesar! Gadis-gadis, apakah kamu menyukainya? 😎😎😎
                </p>
                <a href=""><img alt="" class="comimg" src="files/img/coment2.jpg" style="width: 50%;"></a>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-09.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt52" href="">SOULEYMANE</a>
                </p>
                <p class="comment lt53">Saya memesan produk ini, dan saya tidak sabar menunggu lebih lama lagi! Saya ingin mengejutkan pacar saya di tempat tidur!

                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-13.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt54" href="">MALICK</a>
                </p>
                <p class="comment lt55">Kamu gadis yang baik, aku ingin menjadi suamimu, hahaha!</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-11.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt56" href="">AIDA</a>
                </p>
                <p class="comment lt57">Seorang teman saya bercerita banyak tentang produk ini, ini benar-benar berhasil! 😍</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-12.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt58" href="">AMINATA</a>
                </p>
                <p class="comment lt59">Saya membeli <a href="">Alfaman</a> untuk suami saya! Itu luar biasa! Ukuran penis bertambah, durasi berhubungan seks meningkat secara signifikan! Bahkan setelah ejakulasi, penis tetap ereksi!
                </p><a href=""><img alt="" class="comimg" src="files/img/coment3.jpg" style="width: 50%;"></a>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-14.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt60" href="">IBRAHIMA</a>
                </p>
                <p class="comment lt61">Saya membelinya, dan saya bosan! Ha ha!</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-15.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt62" href="">ADAMA</a>
                </p>
                <p class="comment lt63">Percayalah, ini benar-benar berhasil! Saya tidak lagi mengkhawatirkan potensi saya sebelum berhubungan seks. Semuanya berjalan seperti di masa mudaku.</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-16.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt64" href="">ABDOURAHMANE</a>
                </p>
                <p class="comment lt65">Satu-satunya alat yang benar-benar berfungsi.
                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-17.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt66" href="">SAMBA</a>
                </p>
                <p class="comment lt67">Tanpa memberitahu istri saya, saya membeli 3 bungkus; Saya ingin mengejutkannya. Dia terus-menerus bertanya-tanya ada apa denganku karena sekarang aku menidurinya beberapa kali sehari. Dia sepertinya lebih menghargaiku. 😁😍</p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-20.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt68" href="">MBAYE</a>
                </p>
                <p class="comment lt69">Saya membeli <a href="">Alfaman</a> dengan harga diskon. Dikirim dalam tiga hari.
                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-21.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt70" href="">AMADOU</a>
                </p>
                <p class="comment lt71">
                    Saya harap semua orang tahu tentang produk ini! Sekarang saya memiliki penis yang sekeras batu, dan saya dapat berhubungan seks beberapa kali berturut-turut.
                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-19.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt72" href="">KHADIDIATOU</a>
                </p>
                <p class="comment lt73">Saya tahu produk ini. Suami saya meminumnya selama 2 bulan, namun bahkan setelah menghentikannya, efeknya bertahan selama 6 bulan! </p>

            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-22.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt74" href="">ALIOUNE</a>
                </p>
                <p class="comment lt75">
                    Alat ini benar-benar berfungsi! Dan yang terpenting, ini benar-benar aman! Sekarang saya memiliki kehidupan seks yang kaya.
                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-23.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt76" href="">TAMBA</a>
                </p>
                <p class="comment lt77">
                    Saya mencoba <a href="">Alfaman</a> karena penasaran karena harganya murah. Untuk pertama kali dalam hidup saya, saya berhubungan seks selama dua jam, hampir tanpa gangguan!
                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-24.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt78" href="">DAOUDA</a>
                </p>
                <p class="comment lt79">Dimana saya bisa membeli ini?

                </p>
            </div>
        </div>
        <div class="coma" bis_skin_checked="1">
            <div class="col-avatar" bis_skin_checked="1">
                <a href=""><img alt="" class="img-circle" src="files/img/av-27.jpg"></a>
            </div>
            <div class="col-comm-text" style="margin-left: 15px;" bis_skin_checked="1">
                <p class="nickname"><a class="lt80" href="">Hawa</a>
                </p>
                <p class="comment lt81">Untuk menghindari membeli yang palsu, saya sarankan membelinya hanya dari <a
                        href="">website</a> ini.
                </p>
            </div>
        </div>
    </div>
    <div class="otros-commentarios" bis_skin_checked="1">
        <a class="lt82" href="">Komentar lain</a>

    </div>
</main>
<footer>
    <div class="container" bis_skin_checked="1">
        <div class="row" bis_skin_checked="1">
            <div class="offset-md-2 col-md-8 offset-sm-0 col-sm-12" bis_skin_checked="1">
                <div class="col-md-5 col-sm-6 col-5 lt83" bis_skin_checked="1"><b>Sexblog</b>Afrique</div>
                <div class="socialicons" bis_skin_checked="1">
                    <a class="footer-link" href=""
                       style="color: rgb(102, 102, 102);display: block;text-align: center; margin-bottom: 20px;">Kebijakan pribadi</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<center>
    <div class="footer-fixed" bis_skin_checked="1">
        <div bis_skin_checked="1">
            <p><span style="color:#e1c231; padding:0 2px; font-weight:700;"> Diskon -50%.</span> Penawaran berakhir pada: <span id="countdownTimer" data-minutes="47" data-seconds="00"><span class="hours"
                                                                                           style="display: none">00</span><span
                            class="minutes minutesSH">59</span>:<span class="seconds secondsSH">17</span></span></p>
            <a href="">Klik di sini</a>
        </div>
    </div>
</center>


<script>
    $(function () {
        var nowDate = new Date();
        var countDownDiff = Math.ceil((24 * 60 * 60) - (nowDate.getHours() * 60 * 60 + nowDate.getMinutes() * 60 + nowDate.getSeconds()));
        var endDate = new Date(nowDate.getTime() + countDownDiff * 1000);
        setInterval(function () {
            var diffDate = new Date(endDate.getTime() - Date.now()),
                h = (diffDate.getHours() > 9) ? diffDate.getHours() : '0' + diffDate.getHours(),
                m = (diffDate.getMinutes() > 9) ? diffDate.getMinutes() : '0' + diffDate.getMinutes(),
                s = (diffDate.getSeconds() > 9) ? diffDate.getSeconds() : '0' + diffDate.getSeconds();
            $('.hoursSH').html(h);
            $('.minutesSH').html(m);
            $('.secondsSH').html(s);
        }, 1000);
    });
</script>


<script type="text/javascript">
    $("a").click(function (e) {
        e.preventDefault();
        var destination = $('#toform').offset().top;
        jQuery("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, 800);
        return false;
    })
</script>


<!-- INTH_SNIPPET_BOTTOM -->
<div class="ever-popup" bis_skin_checked="1">
    <div class="ever-popup__inner" bis_skin_checked="1">
        <div class="ever-popup__close" bis_skin_checked="1"></div>
    </div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function () {

        //form validation
        let form = document.querySelector('form');

        let phone = form.elements['phone'];
        let submitBtn = form.elements['submit'];

        phone.addEventListener('keypress', function (e) {
            if (e.which !== 8 && e.which !== 43 && isNaN(String.fromCharCode(e.which))) {
                e.preventDefault();
            }
        });

        form.addEventListener('submit', function (e) {
            form.elements['aff_param4'].value = form.elements['name'].value.split(' ')[0];
            form.elements['aff_param5'].value = form.elements['phone'].value.replace(new RegExp('(^00)|(^0)'), '62');
            submitBtn.disabled = true;
            return true;
        });


        document.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector('.toform').scrollIntoView({behavior: "smooth", block: "start"});
            });
        });
    });
</script>

</body>

</html>