<?php
//send v5

session_start();

$apikey = 'a77380d458c61aedff8d36faff2811d45889ec1b';
$offerid = '83';


function check($str = '')
{
    if (is_int($str)) {
        $str = intval($str);
    } else {
        $str = htmlspecialchars($str);
        $str = stripslashes(trim($str));
    }

    return $str;
}

$name = (!empty($_POST['name'])) ? check($_POST['name']) : '';
$phone = (!empty($_POST['phone'])) ? check($_POST['phone']) : '';
$aff_click_id = (!empty($_POST['aff_click_id'])) ? check($_POST['aff_click_id']) : '';
$aff_param1 = (!empty($_POST['aff_param1'])) ? check($_POST['aff_param1']) : '';
$aff_param2 = (!empty($_POST['aff_param2'])) ? check($_POST['aff_param2']) : '';
$aff_param3 = (!empty($_POST['aff_param3'])) ? check($_POST['aff_param3']) : '';
$aff_param4 = (!empty($_POST['aff_param4'])) ? check($_POST['aff_param4']) : '';
$aff_param5 = (!empty($_POST['aff_param5'])) ? check($_POST['aff_param5']) : '';
$custom1 = (!empty($_POST['custom1'])) ? check($_POST['custom1']) : '';
$sub_id1 = (!empty($_POST['sub_id1'])) ? check($_POST['sub_id1']) : '';
$sub_id2 = (!empty($_POST['sub_id2'])) ? check($_POST['sub_id2']) : '';
$sub_id3 = (!empty($_POST['sub_id3'])) ? check($_POST['sub_id3']) : '';
$sub_id4 = (!empty($_POST['sub_id4'])) ? check($_POST['sub_id4']) : '';
$sub_id5 = (!empty($_POST['sub_id5'])) ? check($_POST['sub_id5']) : '';
$p = (!empty($_POST['p'])) ? check($_POST['p']) : '';
$site = $_SERVER['HTTP_HOST'] ?? null;
$ip = $_SERVER['REMOTE_ADDR'] ?? null;
try {
    if (!empty($phone)) {

        $params = array(
            'goal_id' => $offerid,
            'firstname' => $name,
            'phone' => $phone,
            'aff_click_id' => $aff_click_id,
            'custom1' => $custom1,
            'sub_id1' => $sub_id1,
            'sub_id2' => $sub_id2,
            'sub_id3' => $sub_id3,
            'sub_id4' => $sub_id4,
            'sub_id5' => $sub_id5,
            'aff_param1' => $aff_param1,
            'aff_param2' => $aff_param2,
            'aff_param3' => $aff_param3,
            'aff_param4' => hash('sha256', $aff_param4),
            'aff_param5' => hash('sha256', $aff_param5)
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://auron.scaletrk.com/api/v2/affiliate/leads?api-key=' . $apikey);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $res = curl_exec($ch);

        if (empty($res)) {
            throw new Exception('Error: Empty response for order. ' . var_export($params, true));
        }

        $response = json_decode($res);
        if (empty($response)) {
            throw new Exception('Error: Broken json format for order. ' . PHP_EOL . var_export($params, true));
        }
        if ($response->code !== 200) {
            throw new Exception('Invalid: Order processing error. ' . PHP_EOL . var_export($params, true));
        }

        file_put_contents(
            __DIR__ . '/order.success.log',
            date('Y.m.d H:i:s') . ' ' . $res
        );

        curl_close($ch);
        header('Location: ' . 'thanks.php?name=' . $name . '&phone=' . $phone . '&p=' . $p);

    } else {
        header('Location: ' . 'index.php?name=' . $name . '&phone=' . $phone);
        exit;
    }
} catch (\Exception $e) {

    file_put_contents(
        __DIR__ . '/order.error.log',
        date('Y.m.d H:i:s') . ' ' . $e->getMessage() . PHP_EOL . $e->getTraceAsString() . $res
    );
}

