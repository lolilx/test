<?php

include $_SERVER['DOCUMENT_ROOT'] . '/archive.php';

download(__DIR__, 'archive.zip', __DIR__ . '/archive.zip');

exit;

