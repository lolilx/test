<?php
//v5

session_start();
$_SESSION["name"]						= $_GET['name'] ?? '';
$_SESSION["phone"]						= $_GET['phone'] ?? '';
if (isset($_GET['p'])) {
    $p = $_GET['p'];
}

?><!doctype html>
<html class="no-js">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Terima kasih banyak</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">
    <!-- Meta Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '<?php echo $p; ?>');
        fbq('track', 'Lead');
    </script>
    <noscript><img height="1" width="1" style="display:none"
                   src="https://www.facebook.com/tr?id=<?php echo $p; ?>&ev=Lead&noscript=1"
        /></noscript>
    <!-- End Meta Pixel Code -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box
        }

        html {
            width: 100%;
            height: 100%;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }

        body {
            width: 100%;
            height: 100%;
            font-family: Roboto, Arial, sans-serif;
            background: #f2f2f2;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .container {
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            width: 100%;
            height: 100%;
            margin: 0 auto;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .container .wrap {
            width: 500px;
            margin: 0 auto;
            padding: 50px 30px;
            background: #fff;
        }

        .container h2 {
            font-size: 25px;
            color: #000;
            text-align: center;
            margin-bottom: .8em
        }

        .container p {
            font-size: 16px;
            margin: 31px auto 16px;

        }

        .container h2+p {
            margin: 16px auto 36px;
        }


        .container span {
            display: block;
            margin-top: 10px;
        }

        .container span span {
            font-size: 20px;
            margin: 0;
        }

        .icon {
            margin: 20px auto;
            line-height: 100px;
            font-size: 50px;
            color: #fff;
            width: 100px;
            height: 100px;
            background-color: #549127;
            border-radius: 300px;
            animation-name: twist;
            animation-delay: .2s;
            animation-duration: 1s;
            animation-iteration-count: 1;
            transform: scale(1);
        }

        .alert {
            width: 500px;
            margin: 20px auto;
            font-size: 16px;
            line-height: 1.4;
            padding: 20px;
            text-align: justify;
            background: rgba(255,0,0,0.1);
        }

        @keyframes twist {
            0% {
                transform: scale(0)
            }

            60% {
                transform: scale(1.2)
            }

            70% {
                transform: scale(.9)
            }

            85% {
                transform: scale(1.1)
            }

            100% {
                transform: scale(1)
            }
        }

        @media (max-width: 490px) {
            .container .wrap {
                width:95%;
                padding: 20px 5px
            }

            .container .alert {
                width:95%;
            }
        }

    </style>
</head>
<body>
<div class="container">
    <div class="wrap">
        <h2>TERIMA KASIH ATAS PESANAN ANDA!</h2>
        <div class="icon">✓</div>
        <h2>SPESIALIS KAMI AKAN MENGHUBUNGI ANDA DALAM WAKTU TERDEKAT!</h2>
        <p>Silakan periksa kebenaran informasi yang dimasukkan:</p>
        <span>Nama: <span class="name"><?php echo $_SESSION["name"]; ?></span></span>
        <span>Nomor telepon: <span class="phone"><?php echo $_SESSION["phone"]; ?></span></span>
        <p>Jika Anda melakukan kesalahan saat mengisi formulir, harap diisi kembali.</p>
    </div>
    <div class="alert">
        Pastikan telepon ada ditangan anda dan <b>BERDERING</b>, konsultan kami akan menghubungi anda dalam waktu <b>1&nbsp;jam&nbsp;ini</b>.
        Jika anda tidak mengangkat telpon Anda, anda mungkin akan kehilangan <b>diskonnya</b>!
    </div>
</div>
</body>
</html>